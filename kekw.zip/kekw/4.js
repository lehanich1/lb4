const fib = (n) => {
    let prev = 0,
        next = 1;
    let arr = [];
    for (let i = 0; i < n; i++) {
        let temp = next;
        next = prev + next;
        prev = temp;
        arr.push(prev);
    }
    return arr;
};

const express = require("express"); //Импорт модуля express

const app = express(); //объявление express приложения
const port = 8090; //порт, на котором будет работать приложение

app.get("/", (req, res) => {
    // Контроллер для обработки запроса по адресу http://localhost:8080/
    res.json(fib(7));
});
app.listen(port, () => {
    //Запуск приложения. Веб-сервер начинает прослушивать указанный порт
    console.log(`Example app listening at http://localhost:${port}`);
});